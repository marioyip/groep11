CREATE FUNCTION CheckPassword(@pass varchar(30))
    RETURNS int
    AS 
    BEGIN
       DECLARE @retval int

        if len(@pass)>6 and PATINDEX('%[0-9]%', @pass) >0 and PATINDEX('%[a-zA-Z]%', @pass) >0
        SET @retval = 1
        else
        SET @retval = 0

       RETURN @retval
    END;
GO
